#!/bin/bash

condition=$1

if [ $condition == "add" ]; then
    read -p "Enter file name: " filename    
    git add $filename
    git commit
    git push
    
elif [ $condition == "rm" ]; then
    read -p "Enter file name: " filename
    git rm $filename
    git commit
    git push
    
else
    echo 'Sorry, I do not understand this command'
fi
